# List of Pages
> **Note:** This list of pages may not be accurate for all versions, and will be updated to fit the latest version of FRS

## Main Page
This page is the homepage for the application, primarily used to direct users to different pages. It is also the landing page when opening the application

## Session Pages
### Session Pages - In Session
This is the page where the user would be questioned using the card pack of their choice, and asked the questions based on the cards they added

### Session Pages - Select Card Pack
Users are given the opportunity to select one of the card packs they have created, to be quizzed using the cards within this pack

### Session Pages - Statistics
This page shows the user their statistics *(How well they did)* after being quizzed on the questions they created

## Modify Cards
### Modify Cards - Modifying Cards
This page allows users to modify and view cards within a card pack of their choosing

### Modify Cards - Select Card Pack
Users are given the opportunity to select one of the card packs they have created to modify or view the cards within them, create new card packs, or modify the existing ones.

## Flashcards
### Flashcards - Viewing Cards
This page shows a large card *(You are able to click to flip)* allowing users to view and learn with the cards they created

### Flashcards - Select Card Pack
Users are given the opportunity to select one of the card packs they have created to then view the cards within them