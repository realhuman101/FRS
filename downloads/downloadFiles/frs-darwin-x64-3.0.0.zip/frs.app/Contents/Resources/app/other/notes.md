# Ideas
  
## Card pack descriptions
Could use description class and put between amount of cards and title of card pack (could also make it optional and if it is not given just remove altogether)

## New input validation ideas
- remove trailing 's' (could do with `.replace(/[sS]$/g,'')` regex)
- accept numbers only
- accept letters only
- remove any `The`,`A`,`An` etc (could do with `/ the | an | a |The |An |A /g` regex) or even use input to decide what to remove (altho may be bit complex)
- remove specific characters (based on user input)
- remove everything but specific characters (based on user input)
  
## Card Pack settings:
- Ask questions in random order
- Remove hints (if i add hints)
- Give users multiple tries until they get it right (or give them two tries)
- not visible in flashcards or not visible in session
  
## Question Hints
a button that when pressed shows a little tooltip of a hint (could be an optional item to add) could also show hint in card between title and answer

## Export and download cards/card packs
To share with others, download file (perhaps `save.json`)  
importing file will require file validation

## Add multiple possible answers
Possibly right click to delete answer and click button prob with like `+ Add possible valid answer` highlighted link lol

## Rearrange cards
Could have left right buttons on hover (possibly use `position: absolute` and some `left` and `right` values for positioning, maybe even `top` and can use the left right buttoning code I wrote for the flashcards or something similar)

## Multiple answer formats
- Default long paragraph
- Multiple choice
- Checkbox
- Number only
- True/False
> might collide with input validation, solution: only input validation for the long paragraph
  
## Other testing modes:
- Proper test | Shows all questions like paper test format and press submit at bottom to check all
- ~~Match answer with question - might be over complex so might not do~~
*Could have seperate button to show all testing modes besides classic/session and review/flashcards or maybe even include them in or even just flashcards*
  
## ~~Images to questions/cards~~
~~Might not do due to collision with previous possible export and download card ideas, but if I do then can host with gh-pages and create a seperate branch for that~~

## ~~Web version of platform~~
~~Might not do due to collision with node.js~~

## ~~Locally host quiz~~
~~actually might be over complex will prob not do~~