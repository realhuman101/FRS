# Hello!
You have been requested to help test and review the FRS *(Flashcard Revision Software)* application.  
If you accept, you would be required to install the application and complete a survey stating your thoughts on the software.
> To accept this invitation, contact me and I will send you the necessary materials

## Software Information
The Flashcard Revision Software, FRS for short, is an application designed to assist its users in revising on any subject of their choice. To find more information about this application, visit its main page [here](https://github.com/realhuman101/FRS).