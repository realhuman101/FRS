# FRS - Flashcard Revision Software
## Cloning Instructions
Please run the following commands in the following order (also `Node.JS` is required)
- `npm i -D electron@latest`
- `npm install --save-dev @electron-forge/cli`
- `npx electron-forge import`